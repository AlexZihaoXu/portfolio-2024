from game.scenes.game.home import *
from game.scenes.game import *
from game.scenes.game.forest import Forest


class SoulKnight(Window):
    def __init__(self):
        super(SoulKnight, self).__init__()
        self.scene = Forest(self)


if __name__ == '__main__':
    game = SoulKnight()
    game.launch()
