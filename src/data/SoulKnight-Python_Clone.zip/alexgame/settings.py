# AlexGame -> settings
import pygame
from pygame.locals import *

WIN_CAPTION: str = "Soul Knight"
WIN_WIDTH: int = 1280
WIN_HEIGHT: int = 720
WIN_RESIZABLE: bool = False
WIN_ICON: pygame.Surface = pygame.Surface((32, 32), SRCALPHA)

GAME_FPS: int = 2000
GAME_RESOURCE_PATH: str = "game/assets/"
GAME_SCALE: int = 3

SYS_MAX_MEMORY: int = 1024  # In Mb
SYS_MIN_MEMORY: int = 256
SYS_UPDATE_TICK: int = 64
SYS_CACHE_CAPACITY: int = 2048
SYS_COLLECT_INTERVAL: float = 0.01
SYS_COLLECT_PROTECTION: int = 4096

DEBUG_ENABLE: bool = True
DEBUG_SHOW_FPS: bool = True
DEBUG_SHOW_MEMORY_USAGE: bool = True
DEBUG_SHOW: bool = False
