# AlexGame -> log
import datetime

history = ['', '', '']


def output(*values):
    result = ' '.join(str(item) for item in values)
    print(result)


def log(*values):
    now = datetime.datetime.now()
    time = f"[{str(now.hour).rjust(2, '0')}:{str(now.minute).rjust(2, '0')}:{str(now.second).rjust(2, '0')}]"
    main = ' '.join(str(item) for item in values)
    if not (history[-1] == history[-2] == main):
        history.append(main)
        output(time, main)
    if len(history) > 3:
        history.pop(0)


def info(*values, location=''):
    if location:
        log(f"[{location}/INFO]:", *values)
    else:
        log('[INFO]:', *values)


def warn(*values, location=''):
    if location:
        log(f"[{location}/WARN]:", *values)
    else:
        log('[WARN]:', *values)


def err(*values, location=''):
    if location:
        log(f"[{location}/ERROR]:", *values)
    else:
        log('[ERROR]:', *values)

