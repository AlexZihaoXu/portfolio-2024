# AlexGame -> get
import pygame
import math
from typing import Tuple
from alexgame.settings import *
from pygame.locals import *
from alexgame import log

cache = dict()
location = 'get'


def movement(angle) -> Tuple[float, float]:
    angle = 360 - angle
    return (
        math.cos(math.radians(angle)),
        math.sin(math.radians(angle))
    )


def font(filename, size) -> pygame.font.Font:
    filename = GAME_RESOURCE_PATH + filename
    name = f"FONT>{filename}>{size}"
    if name not in cache:
        cache[name] = pygame.font.Font(filename, size)
    return cache[name]


def image(filename: str) -> pygame.Surface:
    filename = GAME_RESOURCE_PATH + filename
    name = f"IMAGE>{filename}"
    if name not in cache:
        try:
            cache[name] = pygame.image.load(filename).convert_alpha()
        except FileNotFoundError as e:
            log.err("Image File", filename, "not found")
            raise e
    return cache[name]


def transparent(surface: pygame.Surface, rate: float) -> pygame.Surface:
    name = f"TRANSPARENT>{surface}>{id(surface)}"
    surface = surface.copy()
    surface.set_alpha(int(rate * 255))
    return surface


def flipped(surface: pygame.Surface) -> pygame.Surface:
    name = f"FLIPPED>{surface}>{id(surface)}"
    if name not in cache:
        cache[name] = pygame.transform.flip(surface, True, False)
    return cache[name]


def brightness(surface: pygame.Surface, rate: float) -> pygame.Surface:
    rate = int(rate*100)
    name = f"BRIGHTNESS>{surface}>{id(surface)}>{rate}"
    if name not in cache:
        rate /= 100
        surface = surface.copy()
        brighten = int(abs(rate) * 255)
        surface.fill((brighten, brighten, brighten), special_flags=(BLEND_RGB_ADD if rate > 0 else BLEND_RGB_SUB))
        cache[name] = surface
    return surface


def rotated(surface: pygame.Surface, angle: float) -> pygame.Surface:
    angle = int(angle / 2) * 2
    name = f"ROTATED>{surface}>{id(surface)}>{angle}"
    if name not in cache:
        cache[name] = pygame.transform.rotate(surface, -angle)
    return cache[name]


def scaled(surface: pygame.Surface, scale: float, compress=True, store=True) -> pygame.Surface:
    if compress:
        scale = int(scale * 100) / 100
    if store:
        name = f"SCALED>{surface}>{id(surface)}>{scale}"
        if name not in cache:
            w, h = surface.get_size()
            cache[name] = pygame.transform.scale(surface, (int(w * scale), int(h * scale)))
        return cache[name]
    w, h = surface.get_size()
    return pygame.transform.scale(surface, (int(w * scale), int(h * scale)))


class Audio:
    def __init__(self, sound: pygame.mixer.Sound):
        self.sound = sound

    def loop(self):
        if self.sound:
            self.sound.play(32)

    def play(self):
        if self.sound:
            self.sound.play()

    def stop(self):
        if self.sound:
            self.sound.stop()


def audio(filename: str) -> Audio:
    filename = GAME_RESOURCE_PATH + filename
    name = f"SOUND>{filename}"
    try:
        if name not in cache:
            cache[name] = pygame.mixer.Sound(filename)
        return Audio(cache[name])
    except pygame.error as e:
        log.err("Failed to load sound", filename)
        return Audio(None)
