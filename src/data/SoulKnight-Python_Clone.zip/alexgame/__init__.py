import os
import time
from itertools import chain
from math import degrees, atan2, acos, hypot

os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"

# Importing Modules
from alexgame import log
from alexgame.locals import *
from pygame.locals import *
from asyncio import sleep as delay
from asyncio import new_event_loop, AbstractEventLoop
from threading import Thread
from typing import List, Tuple, Dict
from pygame import Surface
import psutil
import pygame
import sys
import os

version = '2.0pre1'

# Hello Message
hello_length = 20
log.log(hello_length * '=')
log.log(f"Alex Game v{version}".center(hello_length))
log.log(f"Python: {sys.version.split()[0]}".center(hello_length))
log.log(f"Pygame: {pygame.version.ver}".center(hello_length))
log.log(hello_length * '=')

# Initialization Level-1
location = 'main'
log.info("Initializing Pygame Module", location=location)
try:
    pygame.display.init()
except pygame.error:
    log.err("Fetal Error", "Failed to Initialize Display Module", location='main')
    exit(1)
try:
    pygame.font.init()
except pygame.error:
    log.err("Fetal Error", "Failed to Initialize Font Module", location='main')
    exit(1)
try:
    pygame.mixer.init()
except pygame.error:
    log.err("Error", "Failed to Initialize Sound Module", location='main')
pygame.event.set_allowed((VIDEORESIZE, QUIT))

# Initialization Level-2
log.info("Initializing Window", location=location)
from alexgame.settings import *
from alexgame import get

# Global Variables
DEBUG_FONT = pygame.font.SysFont("Arial", 24)


# Functions


def refresh_screen():
    pygame.display.set_caption(WIN_CAPTION)
    pygame.display.set_icon(WIN_ICON)


def stop(e: Exception = None):
    Window.running = False
    Window.exception = e


def distance(sprite1, sprite2):
    x1, y1 = sprite1.hitbox.rect.center
    x2, y2 = sprite2.hitbox.rect.center
    dx = x2 - x1
    dy = y2 - y1
    return hypot(dx, dy)


def direction(sprite1, sprite2):
    x1, y1 = sprite1.hitbox.rect.center
    x2, y2 = sprite2.hitbox.rect.center
    dx = x2 - x1
    dy = y2 - y1
    result = (degrees(atan2(-dy, dx)) + 90) % 180
    if x1 < x2:
        return -result
    return 180 - result

# Classes


class Keyboard:
    def __init__(self):
        self._pressed_keys = []
        self.update()

    def press(self, key) -> bool:
        return self._pressed_keys[key]

    def update(self):
        self._pressed_keys = pygame.key.get_pressed()


class Mouse:
    def __init__(self):
        self.left = 0
        self.middle = 0
        self.right = 0
        self.x = 0
        self.y = 0

    @property
    def pos(self):
        return self.x, self.y

    def update(self):
        self.left, self.middle, self.right = pygame.mouse.get_pressed()
        self.x, self.y = pygame.mouse.get_pos()

    def __str__(self):
        return f"<Mouse ({self.left}, {self.middle}, {self.right})>"


class Camera:
    def __init__(self):
        self.x = 0
        self.y = 0
        self.slide_delay = 1

    def slideTo(self, x, y):
        self.x += (x - self.x) / self.slide_delay
        self.y += (y - self.y) / self.slide_delay

    @property
    def pos(self):
        return self.x, self.y

    @pos.setter
    def pos(self, new_pos):
        self.x, self.y = new_pos


class Loop:
    def __init__(self, scene):
        self.scene = scene
        self.event_loop: AbstractEventLoop = new_event_loop()
        self.tasks: List = []
        self.sub_loops: List[Loop] = []
        self.thread = Thread(target=self.event_loop.run_forever, name=f"{__class__}")
        self.activated = False

    async def main_process(self):
        while self.activated and self.scene.activated:
            await delay(1 / SYS_UPDATE_TICK)
        self.activated = False

    def create_sub_loop(self):
        loop = Loop(self.scene)
        self.sub_loops.append(loop)
        return loop

    def create_task(self, task):
        self.tasks.append(self.event_loop.create_task(task))

    def start(self):
        self.activated = True
        self.create_task(self.main_process())
        self.thread.start()
        for loop in self.sub_loops:
            loop.start()

    def stop(self):
        self.activated = False
        for loop in self.sub_loops:
            loop.stop()
        for task in self.tasks:
            task.cancel()
        self.event_loop.stop()


def pop_cache():
    try:
        if SYS_COLLECT_PROTECTION > len(get.cache):
            index = -1
        else:
            if len(get.cache)-1 == SYS_COLLECT_PROTECTION:
                index = -1
            else:
                index = rand(SYS_COLLECT_PROTECTION, len(get.cache)-1)
        del get.cache[tuple(get.cache.keys())[index]]
    except Exception:
        pass

class Window:
    refresh_screen()
    screen = pygame.display.set_mode(
        size=(WIN_WIDTH, WIN_HEIGHT),
        flags=HWSURFACE | DOUBLEBUF | (RESIZABLE if WIN_RESIZABLE else 0)
    )
    screen.set_alpha(None)
    running = False
    camera = Camera()
    exception = None
    rect = screen.get_rect()
    process = psutil.Process(os.getpid())

    def __init__(self):
        self._scene: Scene = Scene(self)
        self.events: List[pygame.event.Event] = []
        self.clock = pygame.time.Clock()
        self.keyboard: Keyboard = Keyboard()
        self.mouse = Mouse()

    @property
    def memory(self) -> int:
        return self.process.memory_info().rss

    @property
    def scene(self):
        return self._scene

    @scene.setter
    def scene(self, new_scene):
        self._scene.activated = False
        self._scene.on_disable(self)
        new_scene.activated = True
        new_scene.window = self
        self._scene = new_scene
        new_scene.load(self)

    def update(self):
        self.events: List[pygame.event.Event] = pygame.event.get()
        for event in self.events:
            if event.type == QUIT:
                Window.running = False
        self.keyboard.update()
        self.mouse.update()
        self.scene.update(self)

    def collect_thread(self):
        while self.running:
            memory = self.memory
            if memory > SYS_MAX_MEMORY * MB // 4:
                count = int(memory / (SYS_MAX_MEMORY * MB) * 32)
                for i in range(count):
                    pop_cache()
            pop_cache()
            time.sleep(SYS_COLLECT_INTERVAL)

    def draw(self):
        self.scene.draw(self.screen, self)

    def _draw_debug(self):
        y = 0
        if DEBUG_SHOW_FPS:
            text = DEBUG_FONT.render(
                f"FPS: {self.clock.get_fps() * 10 // 1 / 10}", True,
                Color('white')
            )
            surf = pygame.Surface(text.get_size(), SRCALPHA)
            surf.fill(Color(0, 0, 0, 100))
            surf.blit(text, (0, 0))
            self.screen.blit(
                surf, surf.get_rect(centerx=WIN_WIDTH // 2, top=5 + y)
            )
            y += surf.get_height() + 5
        if DEBUG_SHOW_MEMORY_USAGE:
            rate = self.memory / (SYS_MAX_MEMORY * MB)
            text = DEBUG_FONT.render(
                f"Memory: {self.memory//MB}",
                True,
                Color(255, int(255 * (1 - rate)), int(255 * (1 - rate)))
            )
            surf = pygame.Surface(text.get_size(), SRCALPHA)
            surf.fill(Color(0, 0, 0, 100))
            surf.blit(text, (0, 0))
            self.screen.blit(
                surf, surf.get_rect(centerx=WIN_WIDTH // 2, top=5 + y)
            )
            y += surf.get_height() + 5

    def launch(self):
        Window.running = True
        last_update = 0
        Thread(target=self.collect_thread, name='Window>CollectThread').start()
        while self.running:
            now = time.time()
            if now - last_update > 1 / SYS_UPDATE_TICK:
                self.update()
                last_update = now
            self.draw()
            self._draw_debug()
            pygame.display.flip()
            self.clock.tick(GAME_FPS)
        self.on_disable()

    def on_disable(self):
        self.scene.on_disable(self)
        pygame.display.quit()
        pygame.quit()
        log.info("Game is stopped", location='main')
        if Window.exception:
            raise Window.exception


class Grid(list):
    show = False

    def __init__(self, scene, size=64):
        super().__init__()
        self.scene: Scene = scene
        self.table: Dict[Tuple[int, int], List[Sprite]] = dict()
        self.size = size

    def draw(self, screen: Surface):
        for sprite in self:
            sprite.draw(screen)

    def get_rect(self, rx, ry) -> Rect:
        rect = Rect(
            rx * self.size + settings.WIN_WIDTH // 2,
            ry * self.size + settings.WIN_HEIGHT // 2,
            self.size, self.size)
        return rect

    def find_region(self, x, y):
        return x // self.size, y // self.size

    def get_nearby(self, sprite):
        return chain(
            *(
                (obj for obj in self.get_region(*region) if obj is not sprite)
                for region in sprite.regions if region in self.table
            )
        )

    def find_regions(self, rect: Rect):
        rect.x -= WIN_WIDTH // 2 - Window.camera.x
        rect.y -= WIN_HEIGHT // 2 - Window.camera.y
        top, left = self.find_region(rect.left, rect.top)
        bottom, right = self.find_region(rect.right, rect.bottom)

        return [
            (x, y)
            for x in range(left, right+1)
            for y in range(top, bottom+1)
        ]

    def get_region(self, rx, ry):
        rx = int(rx)
        ry = int(ry)
        try:
            return self.table[(rx, ry)] if (rx, ry) in self.table else []
        except KeyError:
            return []

    def update(self, window: Window):
        for sprite in self:
            sprite.update(window)

    def refresh_grid(self, window: Window):
        for sprite in self:
            regions = self.find_regions(sprite.hitbox.rect)
            for region in sprite.regions:
                if region in self.table:
                    if sprite in self.table[region]:
                        self.table[region].remove(sprite)
                    if not self.table[region]:
                        del self.table[region]
            for region in regions:
                if region not in self.table:
                    self.table[region] = list()
                self.table[region].append(sprite)
            sprite.regions = regions

    def append(self, sprite):
        super(Grid, self).append(sprite)
        regions = self.find_regions(sprite.hitbox.rect)
        if not sprite.loaded:
            sprite.grid = self
            sprite.loaded = True
            sprite.load(self.scene.window)
            sprite.regions = self.find_regions(sprite.hitbox.rect)
        for region in regions:
            if region not in self.table:
                self.table[region] = list()
            self.table[region].append(sprite)

    def remove(self, value):
        sprite = value
        regions = sprite.regions
        for region in regions:
            if region in self.table:
                if sprite in self.table[region]:
                    self.table[region].remove(sprite)
                if not self.table[region]:
                    del self.table[region]
        super().remove(value)

    def pop(self, index: int = ...):
        try:
            sprite = self[index]
            regions = sprite.regions
            for region in regions:
                if region in self.table:
                    self.table[region].remove(sprite)
                    if not self.table[region]:
                        del self.table[region]
            return super(Grid, self).pop(index)
        except IndexError:
            print(1)


class Scene:
    def __init__(self, window: Window):
        self.activated = False
        self.async_loop = Loop(self)
        self.window = window

    def load(self, window: Window):
        self.async_loop.start()

    def draw(self, screen: Surface, window: Window):
        pass

    def update(self, window: Window):
        pass

    def on_disable(self, window: Window):
        self.async_loop.stop()


class BaseHitBox:
    def __init__(self, sprite):
        self.sprite: Sprite = sprite

    @property
    def rect(self) -> Rect:
        return Rect()

    def push(self, hitbox):
        sprite = hitbox.sprite
        own_rect: Rect = self.rect
        rect: Rect = hitbox.rect

        # 1. find directions
        # 2. find the shortest distance of two directions
        # 3. move object base on the shortest distance

        if rect.centerx > own_rect.centerx:  # right side
            x_dire = RIGHT
            x_dis = own_rect.right - rect.left
        else:  # left side
            x_dire = LEFT
            x_dis = rect.right - own_rect.left
        if rect.centery < own_rect.centery:  # top side
            y_dire = TOP
            y_dis = rect.bottom - own_rect.top
        else:  # bottom side
            y_dire = BOTTOM
            y_dis = own_rect.bottom - rect.top

        edges = (
            rect.collidepoint(own_rect.topleft),
            rect.collidepoint(own_rect.topright),
            rect.collidepoint(own_rect.bottomleft),
            rect.collidepoint(own_rect.bottomright)
        )

        motion_fix = 0.8 if edges.count(1) == 1 else 0
        if x_dis < y_dis:
            if x_dire is LEFT:
                sprite.x -= x_dis
            else:
                sprite.x += x_dis
            sprite.y += motion_fix if y_dire is BOTTOM else -motion_fix
        else:
            if y_dire is TOP:
                sprite.y -= y_dis
            else:
                sprite.y += y_dis
            sprite.x += motion_fix if x_dire is RIGHT else -motion_fix


class HitBox(BaseHitBox):
    def __init__(self, sprite):
        super().__init__(sprite)
        self.shift_left: int = 0
        self.shift_right: int = 0
        self.shift_top: int = 0
        self.shift_bottom: int = 0

        self.min_width: int = 0
        self.min_height: int = 0

    @property
    def rect(self):
        rect = self.sprite.rect
        scale = self.sprite.scale
        shift_left, shift_right = (self.shift_right, self.shift_left) if self.sprite.flipped else (
        self.shift_left, self.shift_right)
        rect.x += shift_left * scale
        rect.y += self.shift_top * scale
        rect.width -= (shift_right + shift_left) * scale
        rect.height -= (self.shift_bottom + self.shift_top) * scale

        return rect


class StaticHitBox(BaseHitBox):
    def __init__(self, sprite):
        super().__init__(sprite)
        self.width: int = 0
        self.height: int = 0
        self.align_x: int = CENTER
        self.align_y: int = CENTER
        self.shift_x: int = 0
        self.shift_y: int = 0

    @property
    def rect(self):
        sprite_rect = self.sprite.rect
        scale = self.sprite.scale
        rect = Rect(0, 0, self.width * scale, self.height * scale)
        flipped = self.sprite.flipped
        if self.align_x is CENTER:
            rect.centerx = sprite_rect.centerx
        else:
            if flipped:
                if self.align_x is LEFT:
                    align_x = RIGHT
                else:
                    align_x = LEFT
            else:
                align_x = self.align_x
            if align_x is RIGHT:
                rect.right = sprite_rect.right
            elif align_x is LEFT:
                rect.left = sprite_rect.left

        if self.align_y is CENTER:
            rect.centery = sprite_rect.centery
        elif self.align_y is BOTTOM:
            rect.bottom = sprite_rect.bottom
        elif self.align_y is TOP:
            rect.top = sprite_rect.top

        rect.x += self.shift_x * scale * (-1 if flipped else 1)
        rect.y += self.shift_y * scale
        return rect


class Sprite:
    camera = Window.camera

    def __init__(self, image_group: ImageGroup):
        self.x = 0
        self.y = 0
        self.align_x = CENTER
        self.align_y = CENTER
        self.shift_x = 0
        self.shift_y = 0

        self._flipped = False
        self._scale = GAME_SCALE
        self._rotation = 0
        self._require_update_image = True

        self.image_group = image_group
        self._image: Surface = image_group.present
        self.hitbox = HitBox(self)
        self.loaded = False
        self.regions = [(0, 0)]
        self.grid = None

    @property
    def rect(self) -> Rect:
        rect = self.image.get_rect()
        align_x = self.align_x
        if self.flipped:
            if align_x is LEFT:
                align_x = RIGHT
            elif align_x is RIGHT:
                align_x = LEFT
        x = int(settings.WIN_WIDTH // 2 + self.x - self.camera.x)
        y = int(settings.WIN_HEIGHT // 2 + self.y - self.camera.y)

        if align_x is CENTER:
            rect.centerx = x
        elif align_x is LEFT:
            rect.left = x
        elif align_x is RIGHT:
            rect.right = x

        if self.align_y is CENTER:
            rect.centery = y
        elif self.align_y is TOP:
            rect.top = y
        elif self.align_y is BOTTOM:
            rect.bottom = y

        rect.x += (self.shift_x * (-1 if self.flipped else 1)) * self.scale
        rect.y += self.shift_y * self.scale
        if rect.width == 0:
            rect.width = 1
        if rect.height == 0:
            rect.height = 1
        return rect

    @property
    def image(self):
        return self._image

    @image.setter
    def image(self, new_image):
        if new_image != self._image:
            self._image = new_image
            self._require_update_image = True

    @property
    def real_x(self):
        return settings.WIN_WIDTH // 2 + self.x - self.camera.x

    @real_x.setter
    def real_x(self, value):
        self.x = value - settings.WIN_WIDTH // 2 + self.camera.x

    @property
    def real_y(self):
        return settings.WIN_HEIGHT // 2 + self.y - self.camera.y

    @real_y.setter
    def real_y(self, value):
        self.y = value - settings.WIN_HEIGHT // 2 + self.camera.y

    @property
    def flipped(self):
        return self._flipped

    @flipped.setter
    def flipped(self, value):
        if self._flipped != value:
            self._flipped = value
            self._require_update_image = True

    @property
    def scale(self):
        return self._scale

    @scale.setter
    def scale(self, value):
        if value < 0.01:
            value = 0.01
        if self._scale != value:
            self._scale = value
            self._require_update_image = True

    @property
    def rotation(self):
        return self._rotation

    @rotation.setter
    def rotation(self, value):
        self._rotation = value % 360
        self._require_update_image = True

    def draw(self, screen: Surface):
        if self._require_update_image:
            self.update_image()
        rect = self.rect
        if 0 < rect.right and rect.left < settings.WIN_WIDTH and 0 < rect.bottom and rect.top < settings.WIN_HEIGHT:
            screen.blit(self.image, rect)

        # pygame.draw.rect(screen, Color('red'), self.hitbox.rect, 2)

    def update_image(self):
        if self._scale > 1:
            self.image = get.rotated(
                get.scaled(
                    get.flipped(self.image_group.present) if self.flipped else self.image_group.present,
                    self._scale),
                self._rotation
            )
        else:
            self.image = get.scaled(
                get.rotated(
                    get.flipped(self.image_group.present) if self.flipped else self.image_group.present,
                    self._rotation
                ),
                self._scale
            )
        self._require_update_image = False

    def update(self, window: Window):
        pass

    def load(self, window: Window):
        pass
