import pygame
import os
from alexgame import log, get
from pathlib import Path
from pygame import Surface
from re import findall
from typing import Tuple
from math import cos, sin, radians
from random import randint as rand
from alexgame.settings import *

KB = 1024
MB = KB * KB
GB = MB * KB


def rot_movement(angle) -> Tuple[float, float]:
    return cos(radians(angle)), sin(radians(angle))


class ImageGroup:
    def __init__(self, filename=''):
        filename = filename
        self.index = 0
        self.images = []
        if filename:
            filename = str(filename)
            path = Path(filename)
            names = '|'.join(f"'{name}'" for name in os.listdir(GAME_RESOURCE_PATH+str(path.parent)))
            filename = f"'{path.name}'"
            for image_path in sorted(
                    (f"{path.parent}/{name[1:-1]}" for name in findall(filename, names)),
                    key=lambda i: str(len(i)).rjust(2, '0') + i
            ):
                self.images.append(get.image(image_path))

    def add(self, image):
        self.images.append(image)

    @staticmethod
    def from_surface(surface: Surface):
        group = ImageGroup()
        group.add(surface)
        return group

    def __add__(self, other):
        new_group = self.copy()
        other_type = type(other)
        if other_type is pygame.Surface:
            new_group.images.append(other)
            return new_group
        elif other_type is ImageGroup:
            new_group.images += other.images
            return new_group
        else:
            raise TypeError(f"Unexpected type: {other_type}")

    def copy(self):
        new_group = ImageGroup()
        new_group.index = self.index
        new_group.images = self.images.copy()
        return new_group

    @property
    def present(self) -> pygame.Surface:
        if self.images:
            return self.images[self.index]
        else:
            log.err("[ImageGroup.present] Please add an image to the group first!")

    def next(self) -> pygame.Surface:
        if self.images:
            self.index += 1
            if len(self.images) == self.index:
                self.index = 0
            return self.images[self.index]
        else:
            log.err("[ImageGroup.present] Please add an image to the group first!")


EmptyImageGroup = ImageGroup()
EmptyImageGroup.add(Surface((1, 1), SRCALPHA))

CENTER = 0
TOP = 1
BOTTOM = 2
LEFT = 3
RIGHT = 4

