from alexgame import *


async def drag_loop(entity, window):
    scene = window.scene
    mouse = window.mouse
    await delay(0.1)
    while scene.activated:
        mx, my = mouse.pos
        rect: Rect = entity.hitbox.rect
        if rect.collidepoint(mx, my) and mouse.left:
            ex, ey = entity.x, entity.y
            while scene.activated and mouse.left:
                x, y = mouse.pos
                entity.x = ex - (mx - x)
                entity.y = ey - (my - y)
                await delay(1 / SYS_UPDATE_TICK)
            log.info("New Entity Position: ", (entity.x, entity.y))

        await delay(1 / SYS_UPDATE_TICK)

