from game.scenes.game import *
from game.sprites.entities.enemies.forest import *


class ForestGenerator(RoomGenerator):
    def generate(self):
        x, y = self.room.x, self.room.y
        room = self.room
        scene: GameScene = self.scene

        if room is scene.end_room or room.pos == (0, 0):
            return

        for i in range(rand(3, 5)):
            guard = GoblinGuard()
            guard.x = x + rand(-40, 40) * 8
            guard.y = y + rand(-40, 40) * 8
            room.locked_entities.append(guard)
            scene.entities.append(guard)
            scene.animation_loop.create_task(guard.animation_loop(scene.window))

        for i in range(rand(2, 3)):
            guard = EliteGoblinGuard()
            guard.x = x + rand(-40, 40) * 8
            guard.y = y + rand(-40, 40) * 8
            room.locked_entities.append(guard)
            scene.entities.append(guard)
            scene.animation_loop.create_task(guard.animation_loop(scene.window))


class Forest(GameScene):
    bgm = get.audio("sounds/background/bgm_1Low.wav")

    def load(self, window):
        self.bgm.loop()
        self.player = Knight()
        build_map(
            self,
            ImageGroup("texture/scenes/forest/50[0-4]{1}.png"),
            [
                (get.image("texture/scenes/forest/50.png"), get.image("texture/scenes/forest/55.png")),
                (get.image("texture/scenes/forest/50.png"), get.image("texture/scenes/forest/55.png")),
                (get.image("texture/scenes/forest/505.png"), get.image("texture/scenes/forest/506.png"))
            ],
            generator=ForestGenerator
        )
        super().load(window)

    def draw(self, screen: Surface, window: Window):
        screen.fill(Color(5, 31, 40))
        super(Forest, self).draw(screen, window)

    def on_disable(self, window: Window):
        super().on_disable(window)
        self.bgm.stop()