from game.sprites import *
from game.sprites.entities.enemies import *
from game.sprites.weapons.guns import *
from game.sprites.weapons.melees import *


class Knight(Player):
    def __init__(self):
        super(Knight, self).__init__(
            ImageGroup("texture/sprites/player/c01_[4-7].png"),
            ImageGroup("texture/sprites/player/c01_[0-3].png"),
            get.image("texture/sprites/player/c01_8.png")
        )
        self.target_type = Enemy
        self.shift_x = 12
        self.hitbox.width = 18
        self.hitbox.height = 22
        self.hitbox.align_x = RIGHT
        self.hitbox.align_y = BOTTOM
        self.hitbox.shift_x = -3
        self.hitbox.shift_y = -5

        self.health = [6, 6]
        self.armor = [5, 5]
        self.energy = [180, 180]

        self.weapon = BadPistol(self)
