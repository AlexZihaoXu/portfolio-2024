from game.sprites import *
from game.sprites.particles.emoji import *
from game.sprites.weapons import BaseMelee


class BaseEnemyController(Controller):
    SPEED = 2

    def __init__(self, entity):
        super(BaseEnemyController, self).__init__(entity)
        self.moves = [0, 0, 0, 0]
        self.seed = rand(10, 20) / 12
        self.last_act = self.seed / 2
        self.last_found_target = self.seed
        self.attack_time = time.time() + 3 + self.seed * 2

    def activate(self, window):
        scene: GameScene = window.scene
        rect = self.entity.rect
        rect.x -= window.camera.x
        rect.y -= window.camera.y
        now = time.time()
        if now - self.last_found_target > 12 and self.entity.target:
            self.last_found_target = now - (1 - self.seed) * 3
            self.attack_time = now + 1*self.seed
            scene.particles.append(AttentionEmoji(self.entity))
        if self.entity.target and self.attack_time < now:
            dis = (self.entity.x - self.entity.target.x) ** 2 + (self.entity.y - self.entity.target.y)
            if isinstance(self.entity.weapon, BaseMelee):
                if dis < 10 ** 2:
                    self.entity.weapon.activate(self.entity, scene, window)
                    self.attack_time = now + 2 * self.seed
            else:
                self.entity.weapon.activate(self.entity, scene, window)
                self.attack_time = now + 2 * self.seed

        try:
            if self.entity.weapon and isinstance(self.entity.weapon, BaseMelee):
                if now - self.last_act > 2 * self.seed:
                    self.last_act = now
                elif now - self.last_act > 0.2 * self.seed:
                    entity = self.entity
                    target = entity.target
                    # self.moves = [0, 0, 0, 0]
                    if entity.x < target.x:
                        self.moves[1] = 1
                    else:
                        self.moves[0] = 1
                    if entity.y < target.y:
                        self.moves[2] = 1
                    else:
                        self.moves[3] = 1

                    for i in range(4):
                        self.moves[i] += rand(-3, 3) / 10
            else:
                if now - self.last_act > 0.5:
                    self.last_act = now + rand(0, 10) / 10
                    if rand(0, 1):
                        for i in range(4):
                            self.moves[i] = rand(-10, 10) / 10
                    else:
                        self.moves = [0, 0, 0, 0]
        except AttributeError:
            pass

        if self.moves[0] > 0:
            self.left()
        if self.moves[1] > 0:
            self.right()
        if self.moves[2] > 0:
            self.down()
        if self.moves[3] > 0:
            self.up()
        try:
            self.update()
        except Exception as e:
            stop(e)


class Enemy(Entity):
    def __init__(self, stand_group, run_group, die):
        super().__init__(stand_group, run_group, die)
        self.target_type = Player

    def load(self, window: Window):
        super(Entity, self).load(window)
        scene = window.scene
