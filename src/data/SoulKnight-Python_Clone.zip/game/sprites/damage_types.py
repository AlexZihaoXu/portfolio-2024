from game.sprites import *
from game.sprites.particles.normal import *


class Projectile(DamageType):
    def __init__(self, image_group, weapon, rotation, target, speed=3):
        super().__init__(image_group, weapon, target)
        self.x = weapon.x
        self.y = weapon.y
        self.rotation = rotation + weapon.info.inaccuracy / 100 * rand(-180, 180)
        self.flipped = weapon.flipped
        self.speed = speed
        self.cal_motion()

    def cal_motion(self):
        speed = self.speed
        x, y = rot_movement(self.rotation)
        if self.flipped:
            x, y = -x, -y
        self.motion = x*speed, y*speed

    def move(self, window: Window):
        scene: GameScene = window.scene
        if not self.done:
            for entity in scene.entities.get_nearby(self):
                if isinstance(entity, self.target) and entity.hitbox.rect.collidepoint(self.real_x, self.real_y):
                    self.done = True
                    entity: Entity = entity
                    entity.slide_speed[0] += self.motion[0] * 0.2
                    entity.slide_speed[1] += self.motion[1] * 0.2
                    entity.hurt(self.weapon.info.damage)
                    rect = entity.rect
                    scene.particles.append(DamagePoint(str(self.weapon.info.damage), rect.centerx, rect.top, True))
                    break
        if not self.done:
            super().move(window)
            for sprite in scene.objects.get_nearby(self):
                if isinstance(sprite, Barrier) and sprite.hitbox.rect.collidepoint(self.real_x, self.real_y):
                    self.done = True
                    break

        if self.done:
            for i in range(rand(1, 3)):
                scene.particles.append(SmallSmoke(self.x, self.y))


class SmallBullet(Projectile):
    def __init__(self, weapon: Weapon, rotation, target: type, speed):
        super(SmallBullet, self).__init__(
            ImageGroup.from_surface(get.image("texture/sprites/bullets/small_bullet.png")),
            weapon=weapon,
            target=target,
            rotation=rotation,
            speed=speed
        )


class LargeBullet(Projectile):
    def __init__(self, weapon: Weapon, rotation, target: type, speed):
        super(LargeBullet, self).__init__(
            ImageGroup.from_surface(get.image("texture/sprites/bullets/large_bullet.png")),
            weapon=weapon,
            target=target,
            rotation=rotation,
            speed=speed
        )


class EnemySmallBullet(Projectile):
    def __init__(self, weapon: Weapon, rotation, target: type, speed):
        super(EnemySmallBullet, self).__init__(
            ImageGroup.from_surface(get.image("texture/sprites/bullets/small_bullet_red.png")),
            weapon=weapon,
            target=target,
            rotation=rotation,
            speed=speed
        )


class EnemyLargeBullet(Projectile):
    def __init__(self, weapon: Weapon, rotation, target: type, speed):
        super(EnemyLargeBullet, self).__init__(
            ImageGroup.from_surface(get.image("texture/sprites/bullets/large_bullet_red.png")),
            weapon=weapon,
            target=target,
            rotation=rotation,
            speed=speed
        )


class EnemySmallRoundBullet(Projectile):
    def __init__(self, weapon: Weapon, rotation, target: type, speed):
        super(EnemySmallRoundBullet, self).__init__(
            ImageGroup.from_surface(get.image("texture/sprites/bullets/small_round_bullet_red.png")),
            weapon=weapon,
            target=target,
            rotation=rotation,
            speed=speed
        )


class NormalBlade(Projectile):
    def __init__(self, weapon: Weapon, target: type):
        super(NormalBlade, self).__init__(
            ImageGroup("texture/sprites/effects/effect_sword_[0-2].png"),
            weapon=weapon,
            target=target,
            rotation=0,
            speed=0
        )
        self._last_frame_switch = time.time()
        self._frame_count = 0
        self.scale = 3.2
        self.flipped = weapon.flipped
        self.hurted = []

    def move(self, window: Window):
        scene: GameScene = window.scene
        self.x = self.weapon.owner.x + 25 * (-1 if self.flipped else 1)
        self.y = self.weapon.owner.y - 50 + self._frame_count * 20

        now = time.time()
        if now - self._last_frame_switch > 0.06:
            self._last_frame_switch = now
            self._frame_count += 1
            self.image = self.image_group.next()

        if self._frame_count > 2:
            self.done = True
        elif not self.done:
            if len(self.hurted) > 3:
                return
            for entity in scene.entities.get_nearby(self):
                if entity in self.hurted:
                    continue
                if isinstance(entity, self.target) and entity.hitbox.rect.colliderect(self.hitbox.rect):
                    entity: Entity = entity
                    motion = rot_movement(self.weapon.rotation + (180 if self.weapon.flipped else 0))
                    entity.slide_speed[0] += motion[0] * 0.5
                    entity.slide_speed[1] += motion[1] * 0.5
                    entity.hurt(self.weapon.info.damage)
                    rect = entity.rect
                    scene.particles.append(DamagePoint(str(self.weapon.info.damage), rect.centerx, rect.top, True))
                    self.hurted.append(entity)