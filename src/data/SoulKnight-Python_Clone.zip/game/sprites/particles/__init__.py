from game.sprites import *
from alexgame import *


class Particle(Sprite):
    def __init__(self, image_group: ImageGroup, x, y):
        super().__init__(image_group)
        self.done = False
        self.x = x
        self.y = y
        self.alpha = 200

    def move(self, window: Window):
        self.image_group.images[0] = get.transparent(self.image_group.images[0], self.alpha/255)
        self.alpha -= 1
        if self.alpha < 100:
            self.done = True
