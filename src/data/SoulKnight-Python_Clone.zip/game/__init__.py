from alexgame import *
from game.settings import *
from alexgame import settings

ENTITY_STAND = 0
ENTITY_RUN = 1
ENTITY_DIE = 2

LABEL_FONT = get.font("font/LockClock.ttf", 8)


def render_label(text: str = '', foreground=Color('white'), background=Color('black')):
    fore_surf = LABEL_FONT.render(text, True, foreground)
    back_surf = LABEL_FONT.render(text, True, background)
    surf = Surface((fore_surf.get_width()+1, fore_surf.get_height()+1), SRCALPHA)
    surf.blit(back_surf, (1, 1))
    surf.blit(fore_surf, (0, 0))
    return surf


BOARD = get.image("texture/sprites/ui/player_info_board.png")


def draw_board(screen, player):
    board = BOARD.copy()
    if "Health Bar":
        a, b = player.health
        if a > 0 and b:
            rect = Rect(16, 5, 58 * (player.health[0] / player.health[1]), 7)
            pygame.draw.rect(board, Color(200, 50, 35), rect)
            rect.x += 1
            rect.y += 1
            rect.width -= 2
            rect.height -= 2
            pygame.draw.rect(board, Color(235, 73, 55), rect)
        text = render_label(f"{a}/{b}", Color('white'))
        board.blit(text, text.get_rect(center=(44, 8)))
    if "armor Bar":
        a, b = player.armor
        if a > 0 and b:
            rect = Rect(16, 15, 58 * (a / b), 7)
            pygame.draw.rect(board, Color(119, 119, 119), rect)
            rect.x += 1
            rect.y += 1
            rect.width -= 2
            rect.height -= 2
            pygame.draw.rect(board, Color(139, 139, 139), rect)
        text = render_label(f"{a}/{b}", Color('white'))
        board.blit(text, text.get_rect(center=(44, 18)))
    if "energy Bar":
        a, b = player.energy
        rect = Rect(16, 25, 58 * (a / b), 7)
        if a > 0 and b:
            pygame.draw.rect(board, Color(18, 95, 158), rect)
            rect.x += 1
            rect.y += 1
            rect.width -= 2
            rect.height -= 2
            pygame.draw.rect(board, Color(25, 118, 198), rect)
        text = render_label(f"{a}/{b}", Color('white'))
        board.blit(text, text.get_rect(center=(44, 28)))
    screen.blit(get.scaled(board, GAME_SCALE, store=False), (10, 10))


class GameScene(Scene):
    def __init__(self, window):
        super(GameScene, self).__init__(window)
        self.animation_loop = self.async_loop.create_sub_loop()
        self.control_loop = self.async_loop.create_sub_loop()
        self.enemy_control_loop = self.control_loop.create_sub_loop()
        self.projectile_loop = self.async_loop.create_sub_loop()

        self.rooms = Grid(self)
        self.decorations = []
        self.objects = Grid(self)
        self.projectiles = Grid(self)
        self.entities = Grid(self)
        self.covers = Grid(self)
        self.particles = Grid(self)

        self.room_poses = []
        self.end_rooms = []

        self.player = None
        self.end_room = None
        self.navigate = Navigate(self)

    async def projectile_process_loop(self, window):
        try:
            await delay(0.2)
            while self.activated:
                await delay(1 / GAME_UPDATE_TICK)
                self.projectiles.refresh_grid(window)
                rm_list = []
                for i, projectile in enumerate(self.projectiles):
                    await delay(0)
                    projectile.move(window)
                    if projectile.done:
                        self.projectiles.remove(projectile)
        except Exception as e:
            stop(e)

    async def particle_process_loop(self, window):
        await delay(0.5)
        try:
            while self.activated:
                await delay(1 / GAME_UPDATE_TICK)
                for i, particle in enumerate(self.particles):
                    particle.move(window)
                    if particle.done:
                        self.particles.remove(particle)
        except Exception as e:
            stop(e)

    def load(self, window: Window):
        super().load(window)
        window.camera.slide_delay = 25
        self.entities.append(self.player)
        self.projectile_loop.create_task(self.projectile_process_loop(window))
        self.animation_loop.create_task(self.particle_process_loop(window))
        self.navigate.refresh()
        for entity in self.entities:
            entity.obj_grid = self.objects

    def update(self, window: Window):
        super().update(window)
        self.objects.refresh_grid(window)
        self.entities.refresh_grid(window)
        self.entities.sort(key=lambda entity: entity.y)
        rect = self.player.hitbox.rect
        for room in self.rooms:
            if room.hitbox.rect.colliderect(rect):
                if not room.activated and not room.clear:
                    room.locked = True
                    room.activated = True
                    room.activate(window.scene)
                if room.clear:
                    room.locked = False

    def draw(self, screen: Surface, window: Window):
        super(GameScene, self).draw(screen, window)
        self.rooms.draw(screen)
        for decoration in self.decorations:
            decoration.draw(screen)
        self.objects.draw(screen)
        self.entities.draw(screen)
        self.covers.draw(screen)
        self.projectiles.draw(screen)
        self.particles.draw(screen)
        draw_board(screen, self.player)
        self.navigate.draw(screen)


class Navigate:
    def __init__(self, scene: GameScene):
        self.scene = scene
        self.width = 0
        self.height = 0

        self.min_x = 0
        self.min_y = 0

        self.poses = []
        self.player = (0, 0)

    def refresh(self):
        self.min_x = min((pos[0][0] for pos in self.scene.room_poses))
        self.width = max((pos[0][0] for pos in self.scene.room_poses)) - \
                     self.min_x + 1
        self.min_y = min((pos[0][1] for pos in self.scene.room_poses))
        self.height = max((pos[0][1] for pos in self.scene.room_poses)) - \
                     self.min_y + 1
        self.poses = [pos[0] for pos in self.scene.room_poses]

    def draw(self, screen: Surface):
        size = 20
        surf = Surface((self.width * size, self.height * size), SRCALPHA)
        dark = Surface((size-1, size-1), SRCALPHA)
        dark.fill(Color(255, 255, 255, 220))

        for room in self.scene.rooms:
            if room.pos is not None and room.rect.colliderect(self.scene.player.hitbox.rect):
                self.player = room.pos

        for y in range(self.height):
            for x in range(self.width):
                if (x+self.min_x, y+self.min_y) in self.poses:
                    if (x+self.min_x, y+self.min_y) == self.player:
                        pygame.draw.rect(surf, Color('white'), Rect(x * size+2, y * size+2, size-3, size-3))
                    else:
                        surf.blit(dark, Rect(x * size+1, y * size+1, size-2, size-2))

        screen.blit(surf, (settings.WIN_WIDTH - self.width * size - 20, 200))


class Controller:
    SPEED = 6

    def __init__(self, entity):
        self.entity = entity
        self.ignored_hitbox_types = []
        self.speed = [0, 0]
        self.do_seek_target = False

    def seek_target(self, scene: GameScene):
        pass

    def up(self):
        self.speed[1] -= self.SPEED

    def down(self):
        self.speed[1] += self.SPEED

    def left(self):
        self.speed[0] -= self.SPEED

    def right(self):
        self.speed[0] += self.SPEED

    def activate(self, window):
        pass

    def update(self):
        if self.speed[0] or self.speed[1]:
            self.entity.stat = ENTITY_RUN
        else:
            self.entity.stat = ENTITY_STAND
        if self.speed[0] and self.speed[1]:
            self.speed[0] *= 0.73
            self.speed[1] *= 0.73
        elif self.entity.target:
            self.entity.flipped = self.entity.x > self.entity.target.x
        elif self.speed[0]:
            if self.speed[0] > 0:
                self.entity.flipped = False
            else:
                self.entity.flipped = True

        for entity in self.entity.obj_grid.get_nearby(self.entity):
            for type_ in self.ignored_hitbox_types:
                if (not isinstance(entity, type_)) and entity.hitbox.rect.colliderect(self.entity.hitbox.rect):
                    entity.hitbox.push(self.entity.hitbox)
                    break
        self.entity.x += self.speed[0]
        self.entity.y += self.speed[1]
        self.speed = [0, 0]


class PlayerOfflineController(Controller):
    SPEED = 5

    def __init__(self, entity):
        super().__init__(entity)
        self.do_seek_target = False
        self.seek_last = 0

    def activate(self, window):
        press = window.keyboard.press
        mouse = window.mouse

        now = time.time()
        # Move Function
        if press(K_MOVE_UP):
            self.up()
        if press(K_MOVE_DOWN):
            self.down()
        if press(K_MOVE_LEFT):
            self.left()
        if press(K_MOVE_RIGHT):
            self.right()
        if press(K_ACTIVE_WEAPON):
            self.entity.weapon.activate(self.entity, window.scene, window)

        if self.entity.target:
            window.camera.slideTo(
                (self.entity.x + self.entity.target.x) // 2,
                (self.entity.y + self.entity.target.y) // 2)
        else:
            window.camera.slideTo(self.entity.x, self.entity.y)
            Window.camera.x += self.speed[0]*0.7
            Window.camera.y += self.speed[1]*0.7

        # Target Seek
        if mouse.left:
            self.entity.weapon.activate(self.entity, window.scene, window)
            self.seek_last = now + 0.4

        if self.do_seek_target:
            target = None
            dis = 99999999
            for entity in self.entity.grid:
                new_dis = ((entity.real_x - mouse.x) ** 2 + (entity.real_y - mouse.y) ** 2)
                if entity is not self.entity and isinstance(entity, self.entity.target_type):
                    if new_dis < dis:
                        dis = new_dis
                        target = entity
            if target and dis < 500 ** 2:
                self.entity.target = target
            else:
                self.entity.target = None

        self.do_seek_target = now < self.seek_last
        self.update()


class WeaponInfo:
    def __init__(
            self,
            damage=0,
            energy_cost=0,
            critical_chance=0,
            inaccuracy=0,
            rounds_per_second=1,
    ):
        self.damage = damage
        self.energy_cost = energy_cost
        self.critical_chance = critical_chance
        self.inaccuracy = inaccuracy
        self.rounds_per_second = rounds_per_second

    @property
    def rps(self):
        return self.rounds_per_second

    @rps.setter
    def rps(self, new_rps):
        self.rounds_per_second = new_rps

    @property
    def damage_per_second(self):
        return self.damage * self.rps

    @damage_per_second.setter
    def damage_per_second(self, new_dps):
        self.damage = new_dps / self.rps

    @property
    def dps(self):
        return self.damage_per_second

    @dps.setter
    def dps(self, new_dps):
        self.damage_per_second = new_dps
