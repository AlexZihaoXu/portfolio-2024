from game.sprites.weapons import *


class Meat(BaseSword):
    def __init__(self, owner: Entity):
        super().__init__(
            owner,
            ImageGroup.from_surface(get.image("texture/sprites/weapons/melee/meat.png"))
        )
        self.info.rps = 5
        self.info.damage = 5


class GoblinScythe(BaseSword):
    def __init__(self, owner: Entity):
        super().__init__(
            owner,
            ImageGroup.from_surface(get.image("texture/sprites/weapons/melee/goblin-scythe.png"))
        )
        self.info.rps = 1.5
        self.info.damage = 7
