from game.sprites.damage_types import *
from game.sprites.weapons import *


class BadPistol(NormalGun):
    def __init__(self, owner: Entity):
        super().__init__(
            get.image("texture/sprites/weapons/gun/bad_pistol.png"),
            owner
        )
        self.info.rps = 3.2
        self.info.damage = 3
        self.info.inaccuracy = rand(5, 7)

        self.damage_type = SmallBullet
        self.speed = 8


class P250Pistol(NormalGun):
    def __init__(self, owner: Entity):
        super().__init__(
            get.image("texture/sprites/weapons/gun/p250-pistol.png"),
            owner
        )
        self.info.rps = 3.4
        self.info.damage = 3
        self.info.inaccuracy = 5

        self.damage_type = SmallBullet
        self.speed = 8


class Shotgun(NormalGun):
    sound = get.audio("sounds/gun/fx_shotgun.wav")

    def __init__(self, owner: Entity):
        super().__init__(
            get.image("texture/sprites/weapons/gun/shot-gun.png"),
            owner
        )
        self.info.rps = 1.2
        self.info.damage = 3
        self.info.inaccuracy = 25
        self.info.energy_cost = 3

        self.damage_type = LargeBullet
        self.speed = 8

    def on_activate(self, player, scene: GameScene, window: Window):
        self.sound.play()
        self._ext_x = 10
        for i in range(5):
            bullet = self.damage_type(self, self.rotation, self.owner.target_type, self.speed)
            bullet.rotation = self.rotation + (i - 2) * 15
            bullet.cal_motion()
            scene.projectiles.append(bullet)
