from game.sprites import *
from game.sprites.damage_types import *


class BaseGun(Weapon):
    pass


class NormalGun(BaseGun):
    sound = get.audio("sounds/gun/fx_gun_1.wav")

    def __init__(self, image: Surface, owner: Entity):
        super(NormalGun, self).__init__(
            owner,
            ImageGroup.from_surface(image)
        )
        self.speed = 3
        self._ext_x = 0
        self.damage_type = SmallBullet

    def move(self):
        flipped = self.owner.flipped
        self.x = self.owner.x + self._ext_x * (-1 if flipped else 1)
        self.y = self.owner.y - 25
        self.flipped = flipped

        target = self.owner.target
        if target:
            self.rotation = direction(self, target) + 90 + (180 if self.flipped else 0)
        else:
            if self.rotation > 180:
                self.rotation %= 90
            self.rotation *= 0.95

        self._ext_x *= 0.9

    def on_activate(self, player, scene: GameScene, window: Window):
        self.sound.play()
        self._ext_x = 10
        bullet = self.damage_type(self, self.rotation, self.owner.target_type, self.speed)
        scene.projectiles.append(bullet)


class BaseMelee(Weapon):
    pass


class BaseSword(BaseMelee):
    sound = (get.audio("sounds/melee/fx_sword1.wav"), get.audio("sounds/melee/fx_sword2.wav"))
    def __init__(self, owner: Entity, image_group: ImageGroup):
        super().__init__(owner, image_group)
        self.damage_type = NormalBlade
        self.length = 4
        self.rot = 0
        self._animation_stat = 0

    def move(self):
        self.flipped = self.owner.flipped
        if self._animation_stat == 0:
            self.rot -= self.rot / 3
            self._force_flip = False
        elif self._animation_stat == 1:
            self.rot += (180 - self.rot) / 5
            if self.rot > 100:
                self._animation_stat = 2
        elif self._animation_stat == 2:
            self.rot += (-100 - self.rot) / 5
            if self.rot < -70:
                self._animation_stat = 0

        face = direction(self, self.owner.target) if self.owner.target else 1

        rotation = (self.rot - abs(face * 0.6) + 30) * (-1 if self.flipped else 1)
        x, y = rot_movement(rotation)
        if self.flipped:
            x = -x
            y = -y
        self.rotation = rotation
        self.x = self.owner.x + x * self.length * GAME_SCALE
        self.y = self.owner.y - 20 + y * self.length * GAME_SCALE

    def on_activate(self, player, scene: GameScene, window):
        choice(self.sound).play()
        self._animation_stat = 1
        scene.projectiles.append(NormalBlade(self, self.owner.target_type))
