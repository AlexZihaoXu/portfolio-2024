from game.sprites import *


class HomeRoom(Room):
    def __init__(self):
        super(HomeRoom, self).__init__(
            get.image("texture/scenes/home/home.png")
        )


class Sofa(Sprite):
    def __init__(self, x, y):
        super().__init__(
            ImageGroup.from_surface(get.image("texture/sprites/rooms/home/sofa.png")),
        )
        self.x = x
        self.y = y


class Desk(Barrier):
    def __init__(self, x, y):
        super().__init__(
            ImageGroup.from_surface(get.image("texture/sprites/rooms/home/desk.png")),
        )
        self.x = x
        self.y = y
        self.hitbox.shift_left = 3
        self.hitbox.shift_right = 3
        self.hitbox.shift_top = -3
        self.hitbox.shift_bottom = 22


class Desktop(Sprite):
    def __init__(self, x, y):
        super().__init__(
            ImageGroup.from_surface(get.image("texture/sprites/rooms/home/desktop.png")),
        )
        self.x = x
        self.y = y


class Snacks(Sprite):
    def __init__(self, x, y):
        super().__init__(
            ImageGroup.from_surface(get.image("texture/sprites/rooms/home/snack.png")),
        )
        self.hitbox = StaticHitBox(self)
        self.x = x
        self.y = y


class SnacksTop(Sprite):
    def __init__(self, x, y):
        super().__init__(
            ImageGroup.from_surface(get.image("texture/sprites/rooms/home/snack-top.png")),
        )
        self.x = x
        self.y = y


class Refrigerator(Barrier):
    def __init__(self, x, y):
        super().__init__(
            ImageGroup.from_surface(get.image("texture/sprites/rooms/home/refrigerator.png")),
        )
        self.x = x
        self.y = y
        self.hitbox.shift_bottom = 23


class GameConsole(Barrier):
    def __init__(self, x, y):
        super().__init__(
            ImageGroup.from_surface(get.image("texture/sprites/rooms/home/game_console.png")),
        )
        self.x = x
        self.y = y
        self.hitbox.shift_bottom = 23
        self.hitbox.shift_right = 15


class GameConsoleLight(Sprite):
    def __init__(self, x, y):
        super().__init__(
            ImageGroup.from_surface(get.image("texture/sprites/rooms/home/game_console_light.png")),
        )
        self.x = x
        self.y = y


class Television(Barrier):
    def __init__(self, x, y):
        super().__init__(
            ImageGroup.from_surface(get.image("texture/sprites/rooms/home/television.png")),
        )
        self.x = x
        self.y = y


class TVLight(Sprite):
    def __init__(self, x, y):
        super().__init__(
            ImageGroup.from_surface(get.image("texture/sprites/rooms/home/tv_light.png")),
        )
        self.x = x
        self.y = y


class Books(Sprite):
    def __init__(self, x, y):
        super().__init__(
            ImageGroup.from_surface(get.image("texture/sprites/rooms/home/books.png")),
        )
        self.x = x
        self.y = y
