from game.sprites import *


class TransferGate(Sprite):
    def __init__(self, scene):
        super(TransferGate, self).__init__(
            ImageGroup("texture/sprites/rooms/transfer_gate_[0-7].png")
        )
        self.scene: GameScene = scene

    async def animation_loop(self):
        while self.scene.activated:
            await delay(1 / 10)
            self.image = self.image_group.next()
