from game.sprites.entities.enemies import *
from game.sprites.weapons.guns import *
from game.sprites.weapons.melees import *


class GoblinGuard(Enemy):
    def __init__(self):
        super(GoblinGuard, self).__init__(
            run_group=ImageGroup("texture/sprites/enemies/forest/goblin_guard/[0-3].png"),
            stand_group=ImageGroup("texture/sprites/enemies/forest/goblin_guard/[4-7].png"),
            die=get.image("texture/sprites/enemies/forest/goblin_guard/8.png")
        )
        self.align_x = RIGHT
        self.align_y = BOTTOM
        self.shift_x = 12

        self.health = [8, 8]

        self.hitbox.width = 16
        self.hitbox.height = 18
        self.hitbox.align_x = RIGHT
        self.hitbox.align_y = BOTTOM
        self.hitbox.shift_x = -3
        self.hitbox.shift_y = -3

        self.controller = BaseEnemyController(self)
        self.weapon = P250Pistol(self)
        self.weapon.damage_type = EnemySmallBullet
        self.weapon.speed = 2

        self.weapon.info.damage = 2


class EliteGoblinGuard(Enemy):
    def __init__(self):
        super(EliteGoblinGuard, self).__init__(
            run_group=ImageGroup("texture/sprites/enemies/forest/elite_goblin_guard/[0-3].png"),
            stand_group=ImageGroup("texture/sprites/enemies/forest/elite_goblin_guard/[4-7].png"),
            die=get.image("texture/sprites/enemies/forest/elite_goblin_guard/8.png")
        )
        self.align_x = RIGHT
        self.align_y = BOTTOM
        self.shift_x = 12

        self.health = [15, 15]

        self.hitbox.width = 16
        self.hitbox.height = 18
        self.hitbox.align_x = RIGHT
        self.hitbox.align_y = BOTTOM
        self.hitbox.shift_x = -3
        self.hitbox.shift_y = -3

        self.controller = BaseEnemyController(self)

        seed = rand(1, 2)
        if seed == 1:
            self.weapon = GoblinScythe(self)
            self.weapon.info.damage = 3
        elif seed == 2:
            self.weapon = Shotgun(self)
            self.weapon.speed = 1
            self.weapon.damage_type = EnemySmallRoundBullet
            self.controller.seed += 2
            self.weapon.info.damage = 3
