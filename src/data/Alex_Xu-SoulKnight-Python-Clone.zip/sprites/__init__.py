from random import choice

from alexgame import *
from alexgame.get import Audio
from game import *
from game.sprites.particles.emoji import *
from game.settings import *


class Room(Sprite):
    def __init__(self, image, pos=None):
        group = ImageGroup()
        group.add(image)
        super(Room, self).__init__(group)
        self.pos = pos
        self.clear = False
        w, h = self.image.get_size()
        self.hitbox = StaticHitBox(self)
        self.hitbox.width = w - 1.3 * 16 * GAME_SCALE
        self.hitbox.height = h - 1.35 * 16 * GAME_SCALE
        self.doors = []
        self.locked_entities = []
        self.activated = False
        self._locked = False

    def load(self, window: Window):
        super().load(window)
        window.scene.async_loop.create_task(self.clear_manager(window.scene))

    def activate(self, scene: GameScene):
        for entity in self.locked_entities:
            scene.control_loop.create_task(entity.control_loop(scene.window))

    async def clear_manager(self, scene):
        await delay(0.5)
        while scene.activated:
            clear = True
            await delay(1 / GAME_UPDATE_TICK)
            for entity in self.locked_entities:
                if not self._locked:
                    entity.health[0] = entity.health[1]
                    entity.slide_speed = [0, 0]
                await delay(1 / GAME_UPDATE_TICK)
                if not entity.died:
                    clear = False
                    break

            self.clear = clear

    @property
    def locked(self):
        return self._locked

    @locked.setter
    def locked(self, value):
        if value != self._locked:
            self._locked = value
            if value:
                for door in self.doors:
                    door.locked = True
            else:
                for door in self.doors:
                    door.locked = False


class DoorTop(Sprite):
    surf = get.image("texture/scenes/door-01.png")
    horizontal = Surface((16 * 5, 17), SRCALPHA)
    vertical = Surface((16, 16 * 5 + 1), SRCALPHA)
    for x in range(5):
        horizontal.blit(surf, (1 + x * 16, 0))
        vertical.blit(surf, (1, x * 16))

    def __init__(self, horizontal=True):

        super(DoorTop, self).__init__(
            ImageGroup.from_surface(self.horizontal if horizontal else self.vertical)
        )
        self._locked = False

    @property
    def locked(self):
        return self._locked

    @locked.setter
    def locked(self, value):
        if self._locked != value:
            self._locked = value
            if value:
                self.hitbox.height = 24
            else:
                self.hitbox.height = 0

    def draw(self, screen: Surface):
        if self._locked:
            super().draw(screen)


class Barrier(Sprite):
    pass


class DoorSide(Barrier):
    sound = get.audio("sounds/fx_door.wav")
    surf = get.image("texture/scenes/door-02.png")
    horizontal = Surface((16 * 5, 17), SRCALPHA)
    vertical = Surface((16, 16 * 5 + 1), SRCALPHA)
    for x in range(5):
        horizontal.blit(surf, (x * 16, 0))
        vertical.blit(surf, (0, x*16))

    def __init__(self, horizontal=True):
        super(DoorSide, self).__init__(
            ImageGroup.from_surface(self.horizontal if horizontal else self.vertical)
        )
        self._locked = False
        self.hrz = horizontal
        self.hitbox = StaticHitBox(self)
        self.hitbox.shift_y = -GAME_SCALE * 3
        self.height = self.rect.height
        self.width = self.rect.width
        self.hitbox.width = self.rect.width
        self.hitbox.height = 0

    @property
    def locked(self):
        return self._locked

    @locked.setter
    def locked(self, value):
        if self._locked != value:
            self.sound.play()
            self._locked = value
            if value:
                self.hitbox.width = self.width
                self.hitbox.height = self.height
                if self.hrz:
                    self.hitbox.height *= 0.6
                else:
                    self.hitbox.width *= 0.8
            else:
                self.hitbox.height = 0

    def draw(self, screen: Surface):
        if self._locked:
            super().draw(screen)


class Entity(Sprite):
    sound_dead = (get.audio("sounds/dead/human1 hurt2.wav"), get.audio("sounds/dead/human2 hurt2.wav"))
    sound_hurt = (Audio(None), )

    def __init__(self, stand_group, run_group, die, controller=None):
        self.stand_group: ImageGroup = stand_group
        self.run_group: ImageGroup = run_group
        self.die_group: ImageGroup = ImageGroup()
        self.die_group.add(die)
        self.stat = ENTITY_STAND
        super(Entity, self).__init__(self.stand_group)
        self.hitbox = StaticHitBox(self)
        self.align_x = RIGHT
        self.align_y = BOTTOM
        self.obj_grid: Grid
        self.opposite: type = Entity
        self.controller = controller if controller else Controller(self)
        self.weapon: Weapon = None
        self.target: Entity = None
        self.target_type: type = None
        self.slide_speed = [0, 0]

        self.health = [0, 0]
        self.armor = [0, 0]
        self.energy = [0, 0]

        self._last_cure = 0

    @property
    def died(self):
        return self.health[0] <= 0

    def hurt(self, value):
        now = time.time()
        self._last_cure = now + 2
        self.armor[0] -= value
        self.armor[0] = min(self.armor[0], self.armor[1])
        if self.armor[0] < 0:
            choice(self.sound_hurt).play()
            self.health[0] += self.armor[0]
            self.armor[0] = 0

    def draw(self, screen: Surface):
        super(Entity, self).draw(screen)
        if self.weapon and self.stat != 2:
            self.weapon.draw(screen)
        # rect = self.hitbox.rect
        # pygame.draw.line(
        #     screen, Color('red'), (rect.centerx, 0), (rect.centerx, settings.WIN_HEIGHT)
        # )
        # pygame.draw.line(
        #     screen, Color('blue'), (0, rect.centery), (settings.WIN_WIDTH, rect.centery)
        # )
        # pygame.draw.rect(screen, Color('red'), self.hitbox.rect, 2)

    async def animation_loop(self, window: Window):
        scene = window.scene
        last_switch = 0
        last_stat = self.stat
        await delay(0.1)
        if self.weapon:
            self.weapon.move()
        while scene.activated:
            now = time.time()
            if now - last_switch > 0.1:
                last_switch = now
                self.image = self.image_group.next()
            if self.stat is not last_stat:
                last_stat = self.stat
                last_switch = now - 0.1
                if self.stat is ENTITY_STAND:
                    self.image_group = self.stand_group
                elif self.stat is ENTITY_RUN:
                    self.image_group = self.run_group
                else:
                    self.image_group = self.die_group
                    self.image = self.image_group.next()
                    choice(self.sound_dead).play()
                    break

            await delay(2 / GAME_UPDATE_TICK)

    async def control_loop(self, window):
        self.controller.ignored_hitbox_types.append(Entity)
        scene: GameScene = window.scene
        await delay(0.1)
        try:
            while scene.activated:
                await delay(1 / GAME_UPDATE_TICK)
                now = time.time()
                if now - self._last_cure > 1:
                    self._last_cure = now
                    if self.armor[0] < self.armor[1]:
                        self.armor[0] += 1
                self.x += self.slide_speed[0]
                self.y += self.slide_speed[1]
                self.slide_speed[0] *= 0.95
                self.slide_speed[1] *= 0.95
                if self.died:
                    self.stat = 2
                    if not isinstance(self, Player):
                        scene.entities.remove(self)
                        scene.decorations.append(self)
                        scene.particles.append(DiedEmoji(self))
                        await delay(GAME_DEATH_DELAY)
                        scene.decorations.remove(self)
                        break
                    else:
                        continue
                self.controller.activate(window)
                if self.weapon:
                    self.weapon.move()
                dis = 99999999
                if self.controller.do_seek_target:
                    self.controller.seek_target(scene)
                else:
                    target = None
                    for entity in self.grid:
                        new_dis = ((entity.x - self.x) ** 2 + (entity.y - self.y) ** 2)
                        if entity is not self and isinstance(entity, self.target_type):
                            if new_dis < dis:
                                dis = new_dis
                                target = entity
                    if target and dis < 500 ** 2:
                        self.target = target
                    else:
                        self.target = None
        except Exception as e:
            stop(e)

    def load(self, window: Window):
        super(Entity, self).load(window)
        scene = window.scene
        scene.animation_loop.create_task(self.animation_loop(window))
        scene.control_loop.create_task(self.control_loop(window))


class Player(Entity):
    sound_hurt = (
        get.audio("sounds/player/fx_hit_p1.wav"),
        get.audio("sounds/player/fx_hit_p2.wav"),
        get.audio("sounds/player/fx_hit_p3.wav"),
        get.audio("sounds/player/fx_hit_p4.wav"),
        get.audio("sounds/player/fx_hit_p5.wav")
    )
    def __init__(self, stand_group, run_group, die):
        super().__init__(stand_group, run_group, die)

    def draw(self, screen: Surface):
        super().draw(screen)

    def load(self, window: Window):
        super().load(window)
        self.controller = PlayerOfflineController(self)


class InvisibleBarrier(Barrier):
    def __init__(self, x, y, width, height):
        super().__init__(EmptyImageGroup)
        self.hitbox = StaticHitBox(self)
        self.hitbox.width = width
        self.hitbox.height = height
        self.x = x
        self.y = y


class DamageType(Sprite):
    def __init__(self,
                 image_group: ImageGroup = EmptyImageGroup,
                 weapon=None,
                 target: type = None,
                 animation_fps: int = 10
                 ):
        super().__init__(image_group)
        self.target = target
        self.animation_fps = animation_fps
        self.weapon = weapon
        self.motion = [0, 0]
        self.done = False

    def move(self, window: Window):
        self.x += self.motion[0]
        self.y += self.motion[1]


class _DamageType(DamageType):
    def __init__(self, weapon, target):
        super().__init__()


class Weapon(Sprite):
    def __init__(self, owner: Entity, image_group: ImageGroup):
        super().__init__(image_group)
        self.info = WeaponInfo()
        self.owner = owner
        self.damage_type: type = _DamageType
        self._last_activate = 0

    def move(self):
        self.x = self.owner.x
        self.y = self.owner.y - 25
        self.flipped = self.owner.flipped

    def activate(self, entity, scene, window):
        now = time.time()
        if (now - self._last_activate) > (1 / self.info.rounds_per_second):
            self._last_activate = now
            self.on_activate(entity, scene, window)

    def on_activate(self, player, scene, window):
        pass
