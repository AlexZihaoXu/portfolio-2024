from game.sprites import *


class SmallSmoke(Particle):
    def __init__(self, x, y):
        r1 = rand(3, 4)
        r2 = rand(1, 3)
        surf = Surface((r1 * 2, r1 * 2), SRCALPHA)
        bright = rand(100, 255)
        pygame.draw.circle(
            surf,
            Color(bright, bright, bright),
            (r1, r1), r1, r1-r2)
        super(SmallSmoke, self).__init__(
            ImageGroup.from_surface(get.scaled(surf, 2)),
            x + rand(-20, 20), y + rand(-20, 20)
        )
        self.alpha = 200
        self.rotation = rand(1, 360)

    def move(self, window: Window):
        self.scale -= 0.1
        self.image_group.images[0].set_alpha(int(self.alpha))
        self.alpha *= 0.98
        if self.scale < 1:
            self.done = True


class DamagePoint(Particle):
    def __init__(self, label, x, y, use_real_pos=False):
        super(DamagePoint, self).__init__(
            ImageGroup.from_surface(render_label(label, Color('red')).convert_alpha()),
            x, y
        )
        if use_real_pos:
            self.real_x = x
            self.real_y = y
        self.scale = 4
        self.alpha = 255

    def move(self, window: Window):
        self.y -= 0.3
        self.scale += 0.01
        self.image_group.images[0].set_alpha(int(self.alpha))
        self.alpha *= 0.95
        if self.alpha < 30:
            self.done = True
