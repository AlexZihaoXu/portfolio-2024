from game.sprites.particles import *
from alexgame import *


class Emoji(Particle):
    def __init__(self, image_group: ImageGroup, entity):
        super().__init__(image_group, 0, 0)
        rect = entity.rect
        self.real_x = rect.right
        self.real_y = rect.top + 8 * GAME_SCALE
        self.move_count = 0

    def move(self, window: Window):
        super().move(window)
        self.y -= 0.15
        self.scale -= 0.005
        self.move_count += 1
        if self.move_count > 120:
            self.done = True


class DiedEmoji(Emoji):
    def __init__(self, entity):
        super().__init__(
            ImageGroup.from_surface(
                get.image("texture/sprites/emoji/died.png")
            ),
            entity
        )


class AttentionEmoji(Emoji):
    def __init__(self, entity):
        super().__init__(
            ImageGroup.from_surface(
                get.image("texture/sprites/emoji/attention.png")
            ),
            entity
        )
        rect = entity.rect
        self.real_x = rect.centerx
        self.real_y = rect.top
        self.entity = entity

    def move(self, window: Window):
        # super().move(window)
        rect = self.entity.rect
        self.real_x = rect.centerx
        self.real_y = rect.top
        self.move_count += 1
        if self.move_count > 120:
            self.done = True