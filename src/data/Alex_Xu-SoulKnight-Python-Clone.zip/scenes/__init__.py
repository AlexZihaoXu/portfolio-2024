from alexgame import *
from random import choice

from game.sprites import *


class HallWay(Room):
    pass


class Generator:
    @staticmethod
    def generate_room(
            scene: GameScene, width: int, height: int, materials: ImageGroup, walls: List[Tuple[Surface, Surface]],
            top=False, bottom=False, left=False, right=False, pos=(0, 0)
    ) -> Tuple[
        Tuple[Surface, Surface, Surface, Surface, Surface],
        Tuple[Tuple[int, int], Tuple[int, int], Tuple[int, int], Tuple[int, int], Tuple[int, int]]] \
            :
        # Calculate Image
        width = width * 2 + 5
        height = height * 2 + 5
        if type(pos[0]) not in (int, float):
            base_room, on_left = pos
            room_size = (
                base_room.image.get_width() // 16,
                base_room.image.get_height() // 16
            )
            if room_size[0] > room_size[1]:
                pos = (
                    base_room.x - ((room_size[0] + width + 2) * 16 // 2) * GAME_SCALE * (1 if on_left else -1),
                    base_room.y
                )
            else:
                pos = (
                    base_room.x,
                    base_room.y - ((room_size[1] + height + 2) * 16 // 2) * GAME_SCALE * (1 if on_left else -1)
                )

        rx, ry = pos
        images = tuple(image.subsurface((0, 8, 16, 16)).convert() for image in materials.images)
        base = Surface(((width + 2) * 16, (height + 2) * 16), SRCALPHA)

        wall_queue = [
            rand(0, len(walls) - 1)
            for i in range((width + height + 4) * 2 - 4)
        ]

        horizontal_door = Surface((16 * 5, 16))
        vertical_door = Surface((16, 16 * 5))
        for i in range(5):
            horizontal_door.blit(
                get.image("texture/scenes/door-03.png"),
                (i * 16, 0)
            )
            vertical_door.blit(
                get.image("texture/scenes/door-03.png"),
                (0, i * 16)
            )

        for y in range(1, height + 1):
            for x in range(1, width + 1):
                base.blit(
                    choice(images),
                    (x * 16, y * 16)
                )
        queue = wall_queue.copy()

        if left:
            base.blit(vertical_door, (0, ((height - 5) // 2 + 1) * 16))

        if right:
            base.blit(vertical_door, ((width + 1) * 16, ((height - 5) // 2 + 1) * 16))

        for x in range(width + 2):
            i = queue.pop()
            if top:
                if not ((width - 3) // 2 <= x < (width - 3) // 2 + 5):
                    base.blit(walls[i][0], (x * 16, 8))
            else:
                base.blit(walls[i][0], (x * 16, 8))
            i = queue.pop()
            if bottom:
                if not ((width - 3) // 2 <= x < (width - 3) // 2 + 5):
                    base.blit(walls[i][0], (x * 16, (height + 1) * 16 + 8))
            else:
                base.blit(walls[i][0], (x * 16, (height + 1) * 16 + 8))
        for y in range(height):
            i = queue.pop()
            if left:
                if not ((height - 5) // 2 <= y < (height - 5) // 2 + 5):
                    base.blit(walls[i][0], (0, (y + 1) * 16 + 8))
            else:
                base.blit(walls[i][0], (0, (y + 1) * 16 + 8))
            i = queue.pop()
            if right:
                if not ((height - 5) // 2 <= y < (height - 5) // 2 + 5):
                    base.blit(walls[i][0], ((width + 1) * 16, (y + 1) * 16 + 8))
            else:
                base.blit(walls[i][0], ((width + 1) * 16, (y + 1) * 16 + 8))

        top_surf = Surface(((width + 2) * 16, 16), SRCALPHA)
        bottom_surf = top_surf.copy()
        left_surf = Surface((16, height * 16), SRCALPHA)
        right_surf = left_surf.copy()

        queue = wall_queue
        for x in range(width + 2):
            i = queue.pop()
            top_surf.blit(walls[i][1], (x * 16, 0))
            i = queue.pop()
            bottom_surf.blit(walls[i][1], (x * 16, 0))

        for y in range(height):
            i = queue.pop()
            left_surf.blit(walls[i][1], (0, y * 16))
            i = queue.pop()
            right_surf.blit(walls[i][1], (0, y * 16))

        if top:
            pos = (((width - 3) // 2) * 16, 0)
            top_surf.blit(horizontal_door, (pos[0], 0), special_flags=BLEND_RGBA_SUB)
            base.blit(horizontal_door, pos)
        if bottom:
            pos = (((width - 3) // 2) * 16, (height + 1) * 16)
            bottom_surf.blit(horizontal_door, (pos[0], 0), special_flags=BLEND_RGBA_SUB)
            base.blit(horizontal_door, pos)
        if left:
            pos = (0, ((height - 5) // 2) * 16)
            left_surf.blit(vertical_door, (0, pos[1]), special_flags=BLEND_RGBA_SUB)
        if right:
            pos = ((width + 1) * 16, ((height - 5) // 2) * 16)
            right_surf.blit(vertical_door, (0, pos[1]), special_flags=BLEND_RGBA_SUB)

        # Place Sprites
        surfs = (top_surf, bottom_surf, left_surf, right_surf)
        poses = (
            (rx, ry - ((height - 5) // 2 + 3.5) * 16 * GAME_SCALE),  # For Top Object
            (rx, ry + ((height - 5) // 2 + 2.5) * 16 * GAME_SCALE + 1),  # For Bottom Object
            (rx - ((width - 5) // 2 + 3) * 16 * GAME_SCALE, ry - 8 * GAME_SCALE),  # For Left Object
            (rx + ((width - 5) // 2 + 3) * 16 * GAME_SCALE, ry - 8 * GAME_SCALE),  # For Right Object
        )
        room = Room(base)
        room.x, room.y = (rx, ry)
        scene.rooms.append(room)
        for i in range(4):
            cover = Sprite(ImageGroup.from_surface(surfs[i]))
            cover.x, cover.y = poses[i]
            scene.covers.append(cover)

        # Doors
        if bottom:
            doortop = DoorTop()
            doorside = DoorSide()
            doortop.x, doortop.y = doorside.x, doorside.y = poses[1][0], poses[1][1] + 8*GAME_SCALE
            doortop.y -= 16 * GAME_SCALE
            scene.covers.append(doortop)
            scene.objects.append(doorside)

            room.doors.append(doortop)
            room.doors.append(doorside)

        if top:
            doortop = DoorTop()
            doorside = DoorSide()
            doortop.x, doortop.y = doorside.x, doorside.y = poses[0][0], poses[0][1] + 8 * GAME_SCALE
            doortop.y -= 16 * GAME_SCALE
            scene.covers.append(doortop)
            scene.objects.append(doorside)

            room.doors.append(doortop)
            room.doors.append(doorside)

        if left:
            doortop = DoorTop(False)
            doorside = DoorSide(False)
            doortop.x, doortop.y = doorside.x, doorside.y = poses[2][0], poses[2][1] + 8 * GAME_SCALE
            doortop.y -= 16 * GAME_SCALE
            scene.covers.append(doortop)
            scene.objects.append(doorside)

            room.doors.append(doortop)
            room.doors.append(doorside)

        if right:
            doortop = DoorTop(False)
            doorside = DoorSide(False)
            doortop.x, doortop.y = doorside.x, doorside.y = poses[3][0], poses[3][1] + 8 * GAME_SCALE
            doortop.y -= 16 * GAME_SCALE
            scene.covers.append(doortop)
            scene.objects.append(doorside)

            room.doors.append(doortop)
            room.doors.append(doorside)

        # Place Barriers
        w, h = top_surf.get_size()
        for i, part in enumerate((top, bottom)):
            if part:
                x, y = poses[i]
                nw = (w - 5 * 16) // 2
                scene.objects.append(InvisibleBarrier(x - (40 + nw // 2) * GAME_SCALE, y, nw, h))
                scene.objects.append(InvisibleBarrier(x + (40 + nw // 2) * GAME_SCALE, y, nw, h))
            else:
                x, y = poses[i]
                barrier = InvisibleBarrier(x, y, w, h)
                scene.objects.append(barrier)

        w, h = left_surf.get_size()
        for i, part in enumerate((left, right)):
            if part:
                x, y = poses[i + 2]
                nh = (h - 5 * 16) // 2
                scene.objects.append(InvisibleBarrier(x, y - (40 + nh // 2) * GAME_SCALE, w, nh))
                scene.objects.append(InvisibleBarrier(x, y + (40 + nh // 2) * GAME_SCALE, w, nh))
            else:
                x, y = poses[i + 2]
                barrier = InvisibleBarrier(x, y, w, h)
                scene.objects.append(barrier)

        return room

    @staticmethod
    def generate_horizontal_hallway(
            scene: GameScene, materials: ImageGroup, walls: List[Tuple[Surface, Surface]], base_room: Room,
            left=False
    ):
        width, height = 19 + rand(1, 5) * 2, 7

        base = Surface((width * 16, height * 16), SRCALPHA)

        room_size = (
            base_room.image.get_width() // 16,
            base_room.image.get_height() // 16
        )
        pos = (
            base_room.x + (room_size[0] + width) // 2 * 16 * GAME_SCALE * (-1 if left else 1),
            base_room.y
        )

        images = tuple(image.subsurface((0, 8, 16, 16)).convert() for image in materials.images)

        for y in range(1, height - 1):
            for x in range(width):
                base.blit(choice(images), (x * 16, y * 16))

        top_surf = Surface((width * 16, 16), SRCALPHA)
        bottom_surf = top_surf.copy()

        for x in range(width):
            image = choice(walls)
            base.blit(image[0], (x * 16, 8))
            top_surf.blit(image[1], (x * 16, 0))
            image = choice(walls)
            base.blit(image[0], (x * 16, height*16 - 8))
            bottom_surf.blit(image[1], (x * 16, 0))

        room = HallWay(base)
        room.x, room.y = pos
        scene.rooms.append(room)

        top = Sprite(ImageGroup.from_surface(top_surf))
        top.x, top.y = pos[0], pos[1] - (height//2 * 16 + 8) * GAME_SCALE
        top_barrier = InvisibleBarrier(top.x, top.y, top.image.get_width(), top.image.get_height())
        scene.covers.append(top)
        scene.objects.append(top_barrier)

        bottom = Sprite(ImageGroup.from_surface(bottom_surf))
        bottom.x, bottom.y = pos[0], pos[1] + (height // 2 * 16 - 8) * GAME_SCALE
        bottom_barrier = InvisibleBarrier(bottom.x, bottom.y, bottom.image.get_width(), bottom.image.get_height())
        scene.covers.append(bottom)
        scene.objects.append(bottom_barrier)

        return room

    @staticmethod
    def generate_vertical_hallway(
            scene: GameScene, materials: ImageGroup, walls: List[Tuple[Surface, Surface]], base_room: Room,
            top=False
    ):
        width, height = 7, 19 + rand(1, 5) * 2

        base = Surface((width * 16, height * 16), SRCALPHA)

        room_size = (
            base_room.image.get_width() // 16,
            base_room.image.get_height() // 16
        )
        pos = (
            base_room.x,
            base_room.y + (room_size[1] + height) * 8 * GAME_SCALE * (-1 if top else 1),
        )

        images = tuple(image.subsurface((0, 8, 16, 16)).convert() for image in materials.images)

        for y in range(height):
            for x in range(width):
                base.blit(choice(images), (x * 16, y * 16))

        left_surf = Surface((16, height * 16), SRCALPHA)
        right_surf = left_surf.copy()

        for y in range(height):
            image = choice(walls)
            base.blit(image[0], (0, y * 16))
            left_surf.blit(image[1], (0, y * 16))
            image = choice(walls)
            base.blit(image[0], ((width - 1) * 16, y * 16))
            right_surf.blit(image[1], (0, y * 16))

        room = HallWay(base)
        room.x, room.y = pos
        scene.rooms.append(room)

        top = Sprite(ImageGroup.from_surface(left_surf))
        top.x, top.y = pos[0] - (width // 2 * 16) * GAME_SCALE, pos[1] - 8 * GAME_SCALE
        left_barrier = InvisibleBarrier(top.x, top.y, top.image.get_width(), top.image.get_height())
        scene.covers.append(top)
        scene.objects.append(left_barrier)

        right = Sprite(ImageGroup.from_surface(right_surf))
        right.x, right.y = pos[0] + (width // 2 * 16) * GAME_SCALE, pos[1] - 8 * GAME_SCALE
        right_barrier = InvisibleBarrier(right.x, right.y, right.image.get_width(), right.image.get_height())
        scene.covers.append(right)
        scene.objects.append(right_barrier)

        return room
