from game.scenes import *
from game.sprites.game.home import *
from game.sprites.entities.players import *
from game.sprites.entities.enemies.forest import *

from alexgame.helper import *


class HomeScene(GameScene):
    def __init__(self, window):
        super(HomeScene, self).__init__(window)

    def load(self, window: Window):
        self.rooms.append(HomeRoom())
        self.player = Knight()

        # Four Sides
        self.objects.append(InvisibleBarrier(454, -226, 120, 10))
        self.objects.append(InvisibleBarrier(0, 379, 450, 10))
        self.objects.append(InvisibleBarrier(-234, -225, 275, 10))
        self.objects.append(InvisibleBarrier(-634, 82, 10, 200))
        self.objects.append(InvisibleBarrier(649, 53, 10, 200))
        self.objects.append(InvisibleBarrier(-480, -167, 10, 25))
        self.objects.append(InvisibleBarrier(450, 237, 45, 30))
        self.objects.append(InvisibleBarrier(450, 156, 10, 10))
        self.objects.append(InvisibleBarrier(435, 305, 25, 10))

        self.objects.append(Desk(62, 1))
        self.objects.append(Refrigerator(-243, -137))
        self.objects.append(GameConsole(-525, -115))
        self.objects.append(Snacks(64, -15))

        for i in range(2):
            self.entities.append(EliteGoblinGuard())
        for i in range(2):
            self.entities.append(GoblinGuard())
        # Furniture
        self.decorations.append(Sofa(-28, -167))
        self.decorations.append(Books(-356, 204))

        self.covers.append(Television(448, 213))
        self.covers.append(TVLight(357, 102))
        self.covers.append(GameConsoleLight(-490, -137))
        self.covers.append(Desktop(62, -73))
        self.covers.append(SnacksTop(64, -78))

        super(HomeScene, self).load(window)

    def update(self, window: Window):
        super(HomeScene, self).update(window)
        if window.keyboard.press(K_SPACE):
            window.scene = HomeScene(window)

    def draw(self, screen: Surface, window: Window):
        screen.fill(Color('black'))
        super().draw(screen, window)
