from game.scenes import *
from game.sprites.entities.enemies.forest import GoblinGuard
from game.sprites.entities.players import Knight
from game.sprites.game import *


class RoomGenerator:
    def __init__(self, scene: GameScene, room: Room):
        self.scene: GameScene = scene
        self.room: Room = room

    def generate(self):
        pass


def build_map(scene: GameScene, materials, walls, hallway=None, depth=0, max_depth=3, connect_side=False, dires=(0, 0, 0, 0), pos=(0, 0), generator=RoomGenerator):
    if depth > max_depth:
        return False
    if hallway:
        size = rand(4, 6)
        opens = tuple(rand(0, 1) for i in range(4))
        if opens == (0, 0, 0, 0) and depth < max_depth:
            opens = [0, 0, 0, 0]
            for i in range(2):
                opens[i] = 1

        # opens = (0, 0, 0, 3)

        if depth == max_depth:
            opens = (0, 0, 0, 0)
            size = 5

        room = Generator.generate_room(
            scene, size, size, materials, walls,
            top=dires[0] or opens[0],
            bottom=dires[1] or opens[1],
            left=dires[2] or opens[2],
            right=dires[3] or opens[3],
            pos=(hallway, connect_side)
        )

        if depth == max_depth:
            scene.end_rooms.append(room)

        room.pos = pos
        scene.room_poses.append((pos, None))
        if opens[0] and not dires[0]:
            new_pos = (pos[0], pos[1]-1)
            if new_pos not in scene.room_poses:
                hallway = Generator.generate_vertical_hallway(
                    scene, materials, walls, room,
                    top=True
                )
                build_map(
                    scene, materials, walls, hallway,
                    depth + 1, max_depth, connect_side=True,
                    dires=(0, 1, 0, 0), pos=new_pos,
                    generator=generator
                )
            else:
                print("ERR")
        if opens[1] and not dires[1]:
            new_pos = (pos[0], pos[1] + 1)
            if new_pos not in scene.room_poses:
                hallway = Generator.generate_vertical_hallway(
                    scene, materials, walls, room,
                    top=False
                )
                build_map(
                    scene, materials, walls, hallway,
                    depth + 1, max_depth, connect_side=False,
                    dires=(1, 0, 0, 0), pos=new_pos,
                    generator=generator
                )
            else:
                print("ERR")
        if opens[2] and not dires[2]:
            new_pos = (pos[0]-1, pos[1])
            if new_pos not in scene.room_poses:
                hallway = Generator.generate_horizontal_hallway(
                    scene, materials, walls, room,
                    left=True
                )
                build_map(
                    scene, materials, walls, hallway,
                    depth + 1, max_depth, connect_side=True,
                    dires=(0, 0, 0, 1), pos=new_pos,
                    generator=generator
                )
            else:
                print("ERR")
        if opens[3] and not dires[3]:
            new_pos = (pos[0]+1, pos[1])
            if new_pos not in scene.room_poses:
                hallway = Generator.generate_horizontal_hallway(
                    scene, materials, walls, room,
                    left=False
                )
                build_map(
                    scene, materials, walls, hallway,
                    depth + 1, max_depth, connect_side=False,
                    dires=(0, 0, 1, 0), pos=new_pos,
                    generator=generator
                )
            else:
                print("ERR")

    elif hallway is None:
        r = rand(0, 3)
        dires = [r == i for i in range(4)]
        size = rand(5, 5)
        room = Generator.generate_room(
            scene,
            size, size,
            materials,
            walls,
            dires[0],
            dires[1],
            dires[2],
            dires[3],
        )
        room.pos=(0, 0)
        scene.room_poses.append((pos, None))
        if dires[0]:  # TOP
            hallway = Generator.generate_vertical_hallway(
                scene,
                materials,
                walls,
                room,
                True,
            )
            dires = (0, 1, 0, 0)
            pos = pos[0], pos[1] - 1
            connect_side = True
        elif dires[1]:  # BOTTOM
            hallway = Generator.generate_vertical_hallway(
                scene,
                materials,
                walls,
                room,
                False,
            )
            dires = (1, 0, 0, 0)
            pos = pos[0], pos[1] + 1
            connect_side = False
        elif dires[2]:  # LEFT
            hallway = Generator.generate_horizontal_hallway(
                scene,
                materials,
                walls,
                room,
                True
            )
            dires = (0, 0, 0, 1)
            pos = pos[0] - 1, pos[1]
            connect_side = True
        elif dires[3]:  # RIGHT
            hallway = Generator.generate_horizontal_hallway(
                scene,
                materials,
                walls,
                room,
                False
            )
            dires = (0, 0, 1, 0)
            pos = pos[0] + 1, pos[1]
            connect_side = False
        build_map(
            scene,
            materials,
            walls,
            hallway=hallway,
            depth=depth + 1,
            max_depth=max_depth,
            connect_side=connect_side,
            dires=dires,
            pos=pos,
            generator=generator
        )

    if depth == 0:
        room = choice(scene.end_rooms)
        scene.end_room = room

        for rm in scene.rooms:
            if not isinstance(rm, HallWay):
                generator(scene, rm).generate()

        scene.rooms[0].activated = True
        x, y = room.x, room.y
        transfergate = TransferGate(scene)
        transfergate.x = x
        transfergate.y = y
        scene.animation_loop.create_task(transfergate.animation_loop())
        scene.decorations.append(transfergate)