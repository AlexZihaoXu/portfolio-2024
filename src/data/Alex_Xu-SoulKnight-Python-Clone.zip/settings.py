from pygame.locals import *


GAME_DEATH_DELAY = 5
GAME_UPDATE_TICK = 128 # 128


K_MOVE_UP = K_w
K_MOVE_DOWN = K_s
K_MOVE_LEFT = K_a
K_MOVE_RIGHT = K_d
K_ACTIVE_WEAPON = K_m
